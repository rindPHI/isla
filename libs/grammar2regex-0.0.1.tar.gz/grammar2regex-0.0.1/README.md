# Grammar2Regex

Conversion of the sub grammar starting from a nonterminal in a context-free grammar to a regular expression. If this is not possible, an approximated regular expression is computed.
