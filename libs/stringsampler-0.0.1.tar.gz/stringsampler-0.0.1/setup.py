from setuptools import setup

setup(
    name='stringsampler',
    version='0.0.1',
    packages=['string_sampler'],
    url='https://projects.cispa.saarland/c01dost/stringsmtsampler',
    license='GNU GPLv3',
    author='Dominic Steinhoefel',
    author_email='dominic.steinhoefel@cispa.de',
    description='SMT Sampler with Parse Tree Structure'
)
