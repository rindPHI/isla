import copy
import random
from typing import Tuple, Union, List, Dict, Callable

import itertools
from fuzzingbook.GrammarCoverageFuzzer import GrammarCoverageFuzzer
from fuzzingbook.GrammarFuzzer import tree_to_string
from fuzzingbook.Grammars import is_nonterminal
from fuzzingbook.Parser import EarleyParser, canonical

from string_sampler.helpers import replace_tree_path, list_to_hashable, syntactically_valid, count_nodes, depth, \
    replace_tree
from string_sampler.typ_defs import ParseTree, Grammar, Path, Symbol, IncompleteParseTree


class Mutation:
    """This should be treated as an atomic class."""

    def __init__(self,
                 in_tree: ParseTree,
                 *mutations: Tuple[Path, ParseTree],
                 symbol: Union[Symbol, None] = None,
                 parser: Union[EarleyParser, None] = None,
                 debug_mode: bool = False):
        self.in_tree = in_tree
        self.mutations = mutations
        self.symbol = symbol
        self.parser = parser
        self.debug_mode = debug_mode

        self.__application: Union[None, ParseTree] = None

    def __repr__(self):
        return f"Mutation({repr(self.in_tree)}, {', '.join(map(repr, self.mutations))}, symbol={repr(self.symbol)})"

    def __hash__(self):
        return hash((list_to_hashable(self.in_tree),
                     tuple([(path, list_to_hashable(tree)) for path, tree in self.mutations]),
                     self.symbol))

    def __eq__(self, other):
        if type(other) is not Mutation:
            return False

        other: Mutation
        return (self.in_tree, self.mutations, self.symbol) == (other.in_tree, other.mutations, other.symbol)

    def apply(self):
        if self.__application is None:
            self.__application = copy.deepcopy(self.in_tree)
            for path, replacement_tree in self.mutations:
                self.__application = replace_tree_path(self.__application, path, replacement_tree)

        return self.__application

    def combine(self, mutation_2: 'Mutation') -> 'Mutation':
        mutation_1 = self

        assert mutation_1.symbol == mutation_2.symbol
        assert mutation_1.in_tree == mutation_2.in_tree

        mutations_1: Tuple[Tuple[Path, ParseTree]] = mutation_1.mutations
        mutations_2: Tuple[Tuple[Path, ParseTree]] = mutation_2.mutations

        result_mutations: List[Tuple[Path, ParseTree]] = []

        # First, select all non-conflicting mutations, s.t. there is no mutation
        # in the other mutation set which shares a path prefix
        non_conflicting_1 = [(path_1, tree_1)
                             for path_1, tree_1 in mutations_1
                             if not any(
                [Mutation.is_prefix(path_1, path_2) or
                 Mutation.is_prefix(path_2, path_1)
                 for path_2, _ in mutations_2]
            )]
        non_conflicting_2 = [(path_2, tree_2)
                             for path_2, tree_2 in mutations_2
                             if not any(
                [Mutation.is_prefix(path_2, path_1) or
                 Mutation.is_prefix(path_1, path_2)
                 for path_1, _ in mutations_1]
            )]

        result_mutations += non_conflicting_1
        result_mutations += non_conflicting_2

        conflicting_mutations_1 = tuple([m for m in mutations_1 if m not in non_conflicting_1])
        conflicting_mutations_2 = tuple([m for m in mutations_2 if m not in non_conflicting_2])

        # Now, merge all conflicting mutations (that share a prefix)
        prefix_map: Dict[Path, List[Tuple[Path, ParseTree]]] = {}

        for path, tree in conflicting_mutations_1 + conflicting_mutations_2:
            # Check if there is a prefix
            prefixes = [p for p in prefix_map if p != path and Mutation.is_prefix(p, path)]
            assert len(prefixes) <= 1
            if prefixes:
                prefix_map[prefixes[0]].append((path, tree))
                continue

            # Check if this path is a prefix
            extensions = [p for p in prefix_map if p != path and Mutation.is_prefix(path, p)]
            if extensions:
                prefix_map.setdefault(path, []).append((path, tree))
                for extension in extensions:
                    prefix_map[path].extend(prefix_map[extension])
                    del (prefix_map[extension])
                continue

            prefix_map.setdefault(path, []).append((path, tree))

        assert not any([True
                        for prefix_1, prefix_2 in [(p1, p2)
                                                   for p1 in prefix_map.keys()
                                                   for p2 in prefix_map.keys()
                                                   if p1 != p2]
                        if Mutation.is_prefix(prefix_1, prefix_2) or
                        Mutation.is_prefix(prefix_2, prefix_1)])

        for prefix, mutations in prefix_map.items():
            mutations = sorted(mutations, key=lambda m: len(m[0]))
            assert len(mutations) > 1

            result_tree = mutations[0][1]
            for path, tree in mutations[1:]:
                result_tree = Mutation.merge_trees(path[len(prefix):], result_tree, tree)

            result_mutations.append((prefix, result_tree))

        result = Mutation(copy.deepcopy(mutation_1.in_tree),
                          *result_mutations,
                          symbol=mutation_1.symbol, debug_mode=self.debug_mode)

        if self.debug_mode and self.parser is not None:
            assert syntactically_valid(self.parser, tree_to_string(result.apply()))

        return result

    @staticmethod
    def merge_trees(path: Path, tree_1: ParseTree, tree_2: ParseTree) -> ParseTree:
        """Merges two mutations, where at path in tree_1, there is a subtree compatible with tree_2"""

        node_1, children_1 = tree_1
        node_2, children_2 = tree_2

        children_1: List[ParseTree]
        children_2: List[ParseTree]

        if path:
            if len(children_1) > path[0]:
                return (node_1,
                        children_1[:path[0]] +
                        [Mutation.merge_trees(path[1:], children_1[path[0]], tree_2)] +
                        children_1[path[0] + 1:])
            else:
                # Cannot merge the tree_2 into tree_1, since tree_1 is not deep enough.
                # We return the original tree_1.
                return tree_1

        if not is_nonterminal(node_1):
            # TODO: Should check here if the other nonterminal is a valid alternative at this point.
            # *)
            return tree_1

        if node_1 == node_2:
            if len(children_1) != len(children_2):
                # Here, one could check whether one tree is compatible to a subtree
                # of the other tree, and if so, continue merging... Have to evaluate whether this
                # is a sensible idea. Maybe random choices suffice.
                return random.choice([tree_1, tree_2])

            assert len(children_1) == len(children_2)

            merged_children = []
            for i in range(len(children_1)):
                merged_children.append(Mutation.merge_trees(tuple(), children_1[i], children_2[i]))

            return node_1, merged_children

        # *)
        return tree_1

        # *): We have to return tree_1 (the tree into which the other one is merged)
        #     since otherwise, the result might get syntactically invalid since there
        #     are probably different expansion rules selected.

    @staticmethod
    def is_prefix(tuple_1: Tuple, tuple_2: Tuple) -> bool:
        if len(tuple_1) > len(tuple_2):
            return False

        return tuple_1 == tuple_2[:len(tuple_1)]


class Mutator:
    def applicable(self) -> bool:
        return False

    def apply(self) -> ParseTree:
        pass


class ReplaceBySubtreeMutator(Mutator):
    def __init__(self, inp: ParseTree, path: Path, paths: Dict[Path, ParseTree]):
        self.inp = inp
        self.path = path
        self.subtree = paths[path]

        self.compatible_sub_trees = \
            ParseTreeMutator.filter_trees(self.inp,  # or subtree?
                                          lambda tree: tree != self.subtree and tree[0] == self.subtree[0])

    def applicable(self) -> bool:
        return len(self.compatible_sub_trees) > 0

    def apply(self) -> ParseTree:
        return random.choice(self.compatible_sub_trees)


class ReplaceByRandomTreeMutator(Mutator):
    def __init__(self, inp: ParseTree, path: Path, paths: Dict[Path, ParseTree], fuzzer: GrammarCoverageFuzzer):
        self.inp = inp
        self.path = path
        self.subtree = paths[path]
        self.fuzzer = fuzzer

    def applicable(self) -> bool:
        return True

    def apply(self) -> ParseTree:
        return self.create_random_subtree(self.path)

    def create_random_subtree(self, path):
        node_type = self.subtree[0]
        assert is_nonterminal(node_type)
        random_subtree = (node_type, None)
        return self.fuzzer.expand_tree(random_subtree)


class GeneralizeContextMutator(Mutator):
    def __init__(self, path: Path, paths: Dict[Path, ParseTree],
                 grammar: Grammar, fuzzer: GrammarCoverageFuzzer):
        self.subtree = paths[path]
        self.grammar: Dict[str, List[List[str]]] = canonical(grammar)
        self.fuzzer = fuzzer
        self.depth = min(4, depth(self.subtree))
        self.current_expansion, self.alternatives = self.alternative_expansions()

    def applicable(self) -> bool:
        return len(self.alternatives) > 0

    def apply(self) -> ParseTree:
        alternative = random.choice(self.alternatives)

        assert len(self.current_expansion[1]) == len(self.subtree[1])

        success = False
        incomplete_tree = alternative
        for i in range(len(self.subtree[1])):
            incomplete_tree, _success = replace_tree(incomplete_tree,
                                                     self.current_expansion[1][i],
                                                     self.subtree[1][i], times=1)
            success |= _success

        assert success

        return self.fuzzer.expand_tree(incomplete_tree)

    def alternative_expansions(self) -> Tuple[IncompleteParseTree, List[IncompleteParseTree]]:
        expansions = self.expansions(self.subtree[0], self.depth)

        current_expansion = self.limit_tree(self.subtree, self.depth)

        # Some embedding should be possible, otherwise applying this transformer would be a random
        # replacement. Therefore, we check whether some children occur in the alternatives.
        # Moreover, we require alternatives to be larger than the current expansion. Otherwise,
        # a ReplaceBySubtreeMutator application should be chosen.

        return current_expansion, [expansion for expansion in expansions
                                   if expansion != current_expansion
                                   and count_nodes(expansion) > count_nodes(current_expansion)
                                   and any(child in expansion[1] for child in current_expansion[1])]

    def expansions(self, symbol: str, depth: int) -> List[IncompleteParseTree]:
        if not is_nonterminal(symbol):
            return [(symbol, [])]

        if depth == 0:
            return [(symbol, None)]

        result = []
        rule: List[str]
        for rule in self.grammar[symbol]:
            children_expansions: List[List[Tuple[str, List]]] = [self.expansions(child, depth - 1) for child in rule]
            result += [(symbol, list(subtree_option)) for subtree_option in itertools.product(*children_expansions)]

        return result

    def limit_tree(self, tree: IncompleteParseTree, depth: int) -> IncompleteParseTree:
        symbol, children = tree

        if not is_nonterminal(symbol):
            return symbol, []

        if depth == 0:
            return symbol, None

        return symbol, [self.limit_tree(child, depth - 1) for child in children]


class ParseTreeMutator:
    def __init__(self,
                 grammar: Grammar,
                 inp: ParseTree,
                 symbol: Union[Symbol, None] = None,
                 debug_mode: bool = False):
        self.grammar: Grammar = grammar
        self.inp: ParseTree = inp
        self.symbol = symbol
        self.debug_mode = debug_mode

        self.fuzzer: GrammarCoverageFuzzer = GrammarCoverageFuzzer(grammar)
        self.parser: EarleyParser = EarleyParser(self.grammar)
        self.paths: Dict[Path, ParseTree] = self.collect_paths()

        self.sorted_paths: List[Path] = sorted(self.paths.keys(),
                                               key=lambda path: ParseTreeMutator.tree_size(self.paths[path]))

    def mutate(self) -> Mutation:
        """
        Returns a mutation, that is, a path which is mutated and the new tree for that path.
        """

        path = self.random_path(lambda p: is_nonterminal(self.paths[p][0]))

        available_mutators = [
            ReplaceByRandomTreeMutator(self.inp, path, self.paths, self.fuzzer),
            ReplaceBySubtreeMutator(self.inp, path, self.paths),
            GeneralizeContextMutator(path, self.paths, self.grammar, self.fuzzer)
        ]

        enabled_mutators = [m for m in available_mutators if m.applicable()]
        assert enabled_mutators

        new_tree = random.choice(enabled_mutators).apply()
        result = Mutation(self.inp, (path, new_tree),
                          symbol=self.symbol, parser=self.parser, debug_mode=self.debug_mode)
        if self.debug_mode:
            assert syntactically_valid(self.parser, tree_to_string(result.apply()))

        return result

    def replace_subtree(self, path: Path, replacement_tree: ParseTree) -> ParseTree:
        return replace_tree_path(self.inp, path, replacement_tree)

    @staticmethod
    def filter_trees(tree: ParseTree, filter: Callable[[ParseTree], None]) -> List[ParseTree]:
        node, children = tree

        return ([tree] if filter(tree) else []) + [
            *itertools.chain(*[ParseTreeMutator.filter_trees(child, filter) for child in children])]

    def random_path(self, path_filter: Union[None, Callable[[Path], bool]] = None):
        if path_filter is None:
            paths = self.sorted_paths
        else:
            paths = [path for path in self.sorted_paths if path_filter(path)]

        # Geometric sequence as weights
        weights = list(map(lambda x: 1.1 ** x, reversed(range(0, len(paths)))))
        return random.choices(paths, weights, k=1)[0]

    def collect_paths(self) -> Dict[Path, ParseTree]:
        def _collect_paths(tree: ParseTree, path: Path) -> List[Tuple[Path, ParseTree]]:
            return [(path, tree)] + [result
                                     for i, child in enumerate(tree[1])
                                     for result in _collect_paths(child, path + (i,))]

        return dict(tuple(_collect_paths(self.inp, tuple())))

    @staticmethod
    def tree_size(tree: ParseTree):
        return 1 + sum([ParseTreeMutator.tree_size(child) for child in tree[1]])
