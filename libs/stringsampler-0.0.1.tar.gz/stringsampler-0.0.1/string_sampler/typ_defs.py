from typing import Dict, List, Tuple

Symbol = str
Grammar = Dict[str, List[str]]
ParseTree = Tuple[str, List]
Path = Tuple[int, ...]
