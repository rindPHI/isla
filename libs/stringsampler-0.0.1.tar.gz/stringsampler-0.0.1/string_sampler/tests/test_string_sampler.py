import logging
import string
import unittest
from time import time
from typing import List, Generator, Set, Tuple

import z3
from fuzzingbook.Grammars import US_PHONE_GRAMMAR, srange, CHARACTERS_WITHOUT_QUOTE

from string_sampler.sampler import Assignment, StringSampler, StringSamplerConfiguration, InitialSolutionStrategy


def test_sampler(sampler, target_num_samples) -> Tuple[float, Set[Assignment]]:
    start_time = time()
    solutions = set([])

    while len(solutions) < target_num_samples:
        for new_solutions in sampler.get_solutions():
            solutions.update(new_solutions)
            print(f"{((len(solutions) / target_num_samples) * 100):.2f} %...")

            if len(solutions) >= target_num_samples:
                break

    return time() - start_time, solutions


class TestStringSampler(unittest.TestCase):
    def test_relative_performance_phone_number(self):
        logging.basicConfig(level=logging.DEBUG)

        var = z3.String("var")
        formula: z3.BoolRef = z3.And(
            z3.StrToInt(z3.SubString(var, z3.IntVal(1), z3.IntVal(1))) ==
            z3.StrToInt(z3.SubString(var, z3.IntVal(2), z3.IntVal(1))) - 1,
            z3.StrToInt(z3.SubString(var, z3.IntVal(2), z3.IntVal(1))) ==
            z3.StrToInt(z3.SubString(var, z3.IntVal(3), z3.IntVal(1))) - 1)

        formula_with_re: z3.BoolRef = z3.And(
            formula,
            z3.InRe(var,
                    z3.Concat(
                        z3.Re("("),
                        z3.Range("2", "9"),
                        z3.Range("2", "9"),
                        z3.Range("2", "9"),
                        z3.Re(")"),
                        z3.Range("2", "9"),
                        z3.Range("2", "9"),
                        z3.Range("2", "9"),
                        z3.Re("-"),
                        z3.Range("0", "9"),
                        z3.Range("0", "9"),
                        z3.Range("0", "9"),
                        z3.Range("0", "9"),
                    )))

        target_num_samples = 100

        config = StringSamplerConfiguration(nth_char_for_soft_constraints=1, smt_max_timeout_secs=5)
        duration_string_sampler, _ = test_sampler(
            StringSampler(formula_with_re,
                          grammars={"var": US_PHONE_GRAMMAR},
                          config=config,
                          ),
            target_num_samples)

        duration_naive_sampler, _ = test_sampler(NaiveSMTSampler(formula_with_re), target_num_samples)

        self.assertGreater(duration_naive_sampler, duration_string_sampler * 2)

    def test_relative_performance_names(self):
        logging.basicConfig(level=logging.INFO)

        name_part_grammar = {
            "<start>": ["<uc-letter><lc-letters>"],
            "<lc-letters>": ["", "<lc-letter><lc-letters>"],
            "<uc-letter>": srange(string.ascii_uppercase),
            "<lc-letter>": srange(string.ascii_lowercase),
        }

        middle_names_grammar = {
            "<start>": ["<middle-names>"],
            "<middle-names>": ["", " <uc-letter>. <middle-names>"],
            "<uc-letter>": srange(string.ascii_uppercase),
        }

        first_name = z3.String("first")
        maybe_middle_name = z3.String("middle")
        last_name = z3.String("last")
        formula: z3.BoolRef = z3.And(z3.Length(first_name) > z3.Length(last_name),
                                     z3.Length(maybe_middle_name) >= z3.IntVal(0))

        name_part_z3_re = z3.Concat(z3.Range("A", "Z"), z3.Plus(z3.Range("a", "z")))  # [A-Z][a-z]+
        maybe_middle_z3_re = z3.Star(z3.Concat(z3.Re(" "), z3.Range("A", "Z"), z3.Re(". ")))  # ( [A-Z]. )*

        formula_with_regex = z3.And(formula,
                                    z3.InRe(first_name, name_part_z3_re),
                                    z3.InRe(maybe_middle_name, maybe_middle_z3_re),
                                    z3.InRe(last_name, name_part_z3_re))

        grammars = {"first": name_part_grammar,
                    "middle": middle_names_grammar,
                    "last": name_part_grammar}

        target_num_samples = 2000

        config = StringSamplerConfiguration(nth_char_for_soft_constraints=1,
                                            smt_max_timeout_secs=5,
                                            max_size_new_neighborhood=200)

        config.custom_evaluation = True
        duration_string_sampler, _ = test_sampler(
            StringSampler(formula_with_regex, formula, grammars=grammars, config=config),
            target_num_samples)

        config.custom_evaluation = False
        duration_string_sampler_smt_check, _ = test_sampler(
            StringSampler(formula_with_regex, formula, grammars=grammars, config=config),
            target_num_samples)

        duration_naive_sampler, _ = test_sampler(NaiveSMTSampler(formula_with_regex), target_num_samples)

        # StringSampler with custom evaluation for concrete assignments is more than twice as fast
        # as standard StringSampler, and more than seven times as fast as the naive SMT approach.
        self.assertGreater(duration_naive_sampler, duration_string_sampler * 7)
        self.assertGreater(duration_string_sampler_smt_check, duration_string_sampler)

    def test_json_string_regex(self):
        json_string_regex = z3.Concat(
            z3.Re('"'),
            z3.Star(
                z3.Union(
                    z3.Range("0", "9"), z3.Range("a", "z"), z3.Range("A", "Z"),
                    z3.Re("!"), z3.Re("#"), z3.Re("$"), z3.Re("%"), z3.Re("&"), z3.Re("'"), z3.Re("("), z3.Re(")"),
                    z3.Re("*"), z3.Re("+"), z3.Re(","), z3.Re("-"), z3.Re("."), z3.Re("/"), z3.Re(":"), z3.Re(";"),
                    z3.Re("<"), z3.Re("="), z3.Re(">"), z3.Re("?"), z3.Re("@"), z3.Re("["), z3.Re("]"), z3.Re("^"),
                    z3.Re("_"), z3.Re("`"), z3.Re("{"), z3.Re("|"), z3.Re("}"), z3.Re("~"), z3.Re(" "))),
            z3.Re('"'))

        json_string_grammar = {
            "<start>": ["<string>"],
            "<string>": ['"' + "<characters>" + '"'],
            "<characters>": ["", "<character><characters>"],
            "<character>": srange(CHARACTERS_WITHOUT_QUOTE)
        }

        logging.basicConfig(level=logging.DEBUG)

        var = z3.String("var")
        formula: z3.BoolRef = z3.InRe(var, json_string_regex)

        target_num_samples = 100

        duration_string_sampler, _ = test_sampler(StringSampler(
            formula,
            z3.BoolVal(True),
            grammars={"var": json_string_grammar},
            config=StringSamplerConfiguration(nth_char_for_soft_constraints=1,
                                              smt_max_timeout_secs=5,
                                              custom_evaluation=True),
        ), target_num_samples)

        duration_naive_sampler, _ = test_sampler(NaiveSMTSampler(formula), target_num_samples)

        self.assertGreater(duration_naive_sampler, duration_string_sampler * 2)


class NaiveSMTSampler:
    def __init__(self, formula: z3.BoolRef):
        self.formula: z3.BoolRef = formula

    def get_solutions(self) -> Generator[Set[Assignment], None, None]:
        results: List[Assignment] = []

        while True:
            solver = z3.Solver()
            solver.add(self.formula)

            conjunction = None
            for result in results:
                disjunction = None
                for symbol, symbol_assignment in result.items():
                    unequation = z3.Not(z3.String(symbol) == z3.StringVal(symbol_assignment))
                    disjunction = unequation if disjunction is None else z3.Or(unequation, disjunction)
                conjunction = disjunction if conjunction is None else z3.And(disjunction, conjunction)

            if conjunction is not None:
                solver.add(conjunction)

            solver_result = solver.check()
            assert solver_result == z3.sat

            solution = self.model_to_assignment(solver.model())
            assert solution not in results

            results.append(solution)
            yield {solution}

    @staticmethod
    def model_to_assignment(model: z3.ModelRef) -> Assignment:
        result = Assignment()

        for symbol_ in model.decls():
            symbol = symbol_.name()
            result[symbol] = model[z3.String(symbol)].as_string()

        return result


if __name__ == '__main__':
    unittest.main()
