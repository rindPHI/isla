import re
import unittest
from time import time

import z3

from string_sampler.constraint_eval import ConstraintEvaluator


class TestConstraintEval(unittest.TestCase):
    def test_regex_translation(self):
        json_string_regex = z3.Concat(
            z3.Re('"'),
            z3.Star(
                z3.Union(
                    z3.Range("0", "9"), z3.Range("a", "z"), z3.Range("A", "Z"),
                    z3.Re("!"), z3.Re("#"), z3.Re("$"), z3.Re("%"), z3.Re("&"), z3.Re("'"), z3.Re("("), z3.Re(")"),
                    z3.Re("*"), z3.Re("+"), z3.Re(","), z3.Re("-"), z3.Re("."), z3.Re("/"), z3.Re(":"), z3.Re(";"),
                    z3.Re("<"), z3.Re("="), z3.Re(">"), z3.Re("?"), z3.Re("@"), z3.Re("["), z3.Re("]"), z3.Re("^"),
                    z3.Re("_"), z3.Re("`"), z3.Re("{"), z3.Re("|"), z3.Re("}"), z3.Re("~"), z3.Re(" "))),
            z3.Re('"'))

        evaluator = ConstraintEvaluator()
        python_regex_pattern: re.Pattern = evaluator.translate_re(json_string_regex)
        self.assertTrue(python_regex_pattern.fullmatch('"0123+#~asdfAZ"'))
        self.assertFalse(python_regex_pattern.fullmatch('"0123+#~asdfAZ'))
        self.assertFalse(python_regex_pattern.fullmatch('"0123+#~asdfAZ""'))

        self.assertTrue(evaluator.eval_formula(z3.InRe(z3.StringVal('"0123+#~asdfAZ"'), json_string_regex)))
        self.assertFalse(evaluator.eval_formula(z3.InRe(z3.StringVal('"0123+#~asdfAZ'), json_string_regex)))
        self.assertFalse(evaluator.eval_formula(z3.InRe(z3.StringVal('"0123+#~asdfAZ""'), json_string_regex)))

    def test_eval_full_json_regex(self):
        # This test demonstrates that the custom evaluator is much slower than
        # the SMT solver if we have a very complex regular expression.

        regex_file = open("json_regex.py", "r")
        regex_str = regex_file.read()
        z3_regex = eval(regex_str)
        regex_file.close()

        test_string = " [ { "" : 0 } , true , false , null ] "
        formula = z3.InRe(z3.StringVal(test_string), z3_regex)
        result = False

        start_time = time()
        for _ in range(10):
            solver = z3.Solver()
            solver.add(formula)
            result = solver.check() == z3.sat

        duration_solver = time() - start_time
        print(f"Solver time: {duration_solver}")
        assert result

        evaluator = ConstraintEvaluator()
        start_time = time()
        for _ in range(10):
            result = evaluator.eval(formula)
        duration_evaluator = time() - start_time
        print(f"Evaluator time: {duration_evaluator}")
        assert result



if __name__ == '__main__':
    unittest.main()
