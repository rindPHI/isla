import unittest

from fuzzingbook.GrammarCoverageFuzzer import GrammarCoverageFuzzer
from fuzzingbook.GrammarFuzzer import tree_to_string
from fuzzingbook.Grammars import US_PHONE_GRAMMAR, JSON_GRAMMAR
from fuzzingbook.Parser import EarleyParser

from string_sampler.helpers import get_subtree, pprint_tree
from string_sampler.mutations import ParseTreeMutator, Mutation, GeneralizeContextMutator


class TestParseTreeMutator(unittest.TestCase):
    def test_get_paths(self):
        parser = EarleyParser(US_PHONE_GRAMMAR)
        tree = list(parser.parse("(200)200-0000"))[0]
        mutator = ParseTreeMutator(US_PHONE_GRAMMAR, tree)
        paths = mutator.collect_paths()

        self.assertEqual(paths[(0, 1)], ('<area>', [('<lead-digit>', [('2', [])]),
                                                    ('<digit>', [('0', [])]), ('<digit>', [('0', [])])]))
        self.assertEqual(paths[(0, 5, 0)], ('<digit>', [('0', [])]))
        self.assertEqual(paths[(0, 5, 0, 0)], ('0', []))

    def test_compatible_trees(self):
        tree = ('<digits>', [('<digit>', [('0', [])]),
                             ('<digits>', [('<digit>', [('1', [])]), ('<digit>', [('2', [])])])])
        mutator = ParseTreeMutator(US_PHONE_GRAMMAR, tree)  # Grammar not needed

        compatible_trees = mutator.filter_trees(tree, lambda tree: tree[0] == "<digits>")

        self.assertEqual(2, len(compatible_trees))
        self.assertNotEqual(*compatible_trees)
        self.assertEqual(2, len(compatible_trees[0][1]))
        self.assertEqual(2, len(compatible_trees[1][1]))

    def test_tree_size(self):
        tree = ('<area>', [('<lead-digit>', [('2', [])]), ('<digit>', [('0', [])]), ('<digit>', [('0', [])])])
        self.assertEqual(7, ParseTreeMutator.tree_size(tree))

    def test_non_conflicting_mutation(self):
        tree = ('<area>', [('<lead-digit>', [('2', [])]), ('<digit>', [('0', [])]), ('<digit>', [('0', [])])])

        mutation_1 = Mutation(tree, ((0,), ('<lead-digit>', [('3', [])])))
        mutation_2 = Mutation(tree, ((1,), ('<digit>', [('1', [])])), ((2,), ('<digit>', [('2', [])])))

        self.assertEqual(
            ('<area>', [('<lead-digit>', [('3', [])]), ('<digit>', [('0', [])]), ('<digit>', [('0', [])])]),
            mutation_1.apply())

        self.assertEqual(
            ('<area>', [('<lead-digit>', [('2', [])]), ('<digit>', [('1', [])]), ('<digit>', [('2', [])])]),
            mutation_2.apply())

        self.assertEqual(
            ('<area>', [('<lead-digit>', [('3', [])]), ('<digit>', [('1', [])]), ('<digit>', [('2', [])])]),
            mutation_1.combine(mutation_2).apply())

    def test_conflicting_mutation(self):
        tree = ('<area>', [('<lead-digit>', [('2', [])]), ('<digit>', [('0', [])]), ('<digit>', [('0', [])])])

        mutation_1 = Mutation(tree, ((1,), ('<digit>', [('1', [])])), ((2,), ('<digit>', [('2', [])])))

        mutation_2 = \
            Mutation(tree,
                     (tuple(),
                      ('<area>', [('<lead-digit>', [('3', [])]), ('<digit>', [('0', [])]), ('<digit>', [('0', [])])])))

        for _ in range(100):
            options = [
                ('<area>', [('<lead-digit>', [('3', [])]), ('<digit>', [('0', [])]), ('<digit>', [('0', [])])]),
                ('<area>', [('<lead-digit>', [('3', [])]), ('<digit>', [('1', [])]), ('<digit>', [('0', [])])]),
                ('<area>', [('<lead-digit>', [('3', [])]), ('<digit>', [('0', [])]), ('<digit>', [('2', [])])]),
                ('<area>', [('<lead-digit>', [('3', [])]), ('<digit>', [('1', [])]), ('<digit>', [('2', [])])]),
            ]

            self.assertIn(mutation_1.combine(mutation_2).apply(), options)

    def test_alternative_expansions(self):
        parser = EarleyParser(JSON_GRAMMAR)
        fuzzer = GrammarCoverageFuzzer(JSON_GRAMMAR)

        inp = ' { "key" : "value" } '
        parsed = next(parser.parse(inp))

        pt_mutator = ParseTreeMutator(JSON_GRAMMAR, parsed)

        path_to_element = (0, 0, 1, 0, 1)
        subtree = get_subtree(path_to_element, parsed)

        assert subtree[0] == "<members>"
        assert tree_to_string(subtree) == ' "key" : "value" '

        mutator = GeneralizeContextMutator(path_to_element, pt_mutator.collect_paths(), JSON_GRAMMAR, fuzzer)
        current_expansion, alternatives = mutator.alternative_expansions()

        self.assertEqual(
            ' "" :  ',
            tree_to_string(current_expansion))

        self.assertEqual(
            [
                ' "" :  ,',
                ' "" :  ,,',
                ' "" :  ,,'
            ],
            list(map(tree_to_string, alternatives)))

    def test_generalize_context_mutator(self):
        parser = EarleyParser(JSON_GRAMMAR)
        fuzzer = GrammarCoverageFuzzer(JSON_GRAMMAR)

        inp = ' { "key" : "value" } '
        parsed = next(parser.parse(inp))

        pt_mutator = ParseTreeMutator(JSON_GRAMMAR, parsed)

        path_to_element = (0, 0, 1, 0, 1)
        subtree = get_subtree(path_to_element, parsed)

        assert subtree[0] == "<members>"
        sub_input = tree_to_string(subtree)
        assert sub_input == ' "key" : "value" '

        mutator = GeneralizeContextMutator(path_to_element, pt_mutator.collect_paths(), JSON_GRAMMAR, fuzzer)
        self.assertTrue(mutator.applicable())

        for _ in range(10):
            mutation = tree_to_string(mutator.apply())
            self.assertIn(sub_input, mutation)
            self.assertGreater(len(mutation), len(sub_input))


if __name__ == '__main__':
    unittest.main()
