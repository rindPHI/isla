from typing import Tuple

from fuzzingbook.Parser import EarleyParser

from string_sampler.typ_defs import Path, ParseTree, IncompleteParseTree


def replace_tree_path(in_tree: ParseTree, path: Path, replacement_tree: ParseTree) -> ParseTree:
    """Returns a symbolic input with a new tree where replacement_tree has been inserted at `path`"""

    def recurse(_tree, _path):
        node, children = _tree

        if not _path:
            return replacement_tree

        head = _path[0]
        new_children = (children[:head] +
                        [recurse(children[head], _path[1:])] +
                        children[head + 1:])

        return node, new_children

    return recurse(in_tree, path)


def replace_tree(in_tree: ParseTree,
                 to_replace: ParseTree,
                 with_tree: ParseTree,
                 times: int = 1) -> Tuple[ParseTree, bool]:
    if times == 0:
        return in_tree, False

    if in_tree == to_replace:
        return with_tree, True

    symbol, children = in_tree

    if not children:
        return (symbol, children), False

    new_children = []
    success = False
    for child in children:
        child_result, _success = replace_tree(child, to_replace, with_tree, times)
        new_children.append(child_result)
        if _success:
            times -= 1
            success = True

    return (symbol, new_children), success


def dfs(tree: IncompleteParseTree, action=print):
    node, children = tree
    action(tree)
    if not children:
        return

    for child in children:
        dfs(child, action)


def count_nodes(parse_tree: ParseTree):
    num = 0

    def count(t):
        nonlocal num
        num += 1

    dfs(parse_tree, count)
    return num


def depth(tree: ParseTree) -> int:
    node, children = tree
    if not children:
        return 1

    return 1 + max([depth(child) for child in children])


def list_to_hashable(a_list):
    if type(a_list) not in (tuple, list):
        return a_list

    return tuple([list_to_hashable(child) for child in a_list])


def syntactically_valid(parser: EarleyParser, inp: str) -> bool:
    try:
        # Will raise exception if there is a syntax error
        next(parser.parse(inp))
        return True
    except SyntaxError:
        return False


def get_subtree(path, tree):
    """Access a subtree based on `path` (a list of children numbers)"""
    node, children = tree

    if not path:
        return tree

    return get_subtree(path[1:], children[path[0]])


def pprint_tree(node, _prefix="", _last=True):
    value, children = node
    print(_prefix, "`- " if _last else "|- ", value, sep="")
    _prefix += "   " if _last else "|  "
    child_count = len(children)
    for i, child in enumerate(children):
        _last = i == (child_count - 1)
        pprint_tree(child, _prefix, _last)
